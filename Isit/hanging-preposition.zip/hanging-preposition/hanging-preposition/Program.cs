﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

class Program
{
    static void Main()
    {
        Console.WriteLine("ИСПРАВЛЯЕМ ВИСЯЧИЕ ПРЕДЛОГИ");
        Console.WriteLine();


        List<string> spisok = new List<string>() {
            "в", "во", "на", "над", "под", "о", "об", "от", "до", "по",
            "из", "у", "без", "для", "к", "с", "за", "при", "про", "между",
            "и", "а", "но", "да", "или", "либо", "ни", "не"
        };

        Console.Write("Введите полный путь к файлу: ");
        string filePath = Console.ReadLine();
        filePath = filePath.Replace("\"", "");

        if (File.Exists(filePath) == false)
        {
            Console.WriteLine("Файл не найден!");
            return;
        }

        string text = File.ReadAllText(filePath);
        string newText = FixText(text, spisok);

        string folder = Path.GetDirectoryName(filePath);
        string fileName = Path.GetFileNameWithoutExtension(filePath);
        string extension = Path.GetExtension(filePath);
        string newFilePath = Path.Combine(folder, fileName + "_new" + extension);

        File.WriteAllText(newFilePath, newText);

        Console.WriteLine("все норм. новый файл: " + newFilePath);
        Console.ReadLine();
    }

    static string FixText(string text, List<string> spisok)
    {
        StringBuilder result = new StringBuilder();
        string[] words = text.Split(' ');

        for (int i = 0; i < words.Length; i++)
        {
            string current = words[i].Trim();

            if (string.IsNullOrEmpty(current))
            {
                result.Append(" ");
                continue;
            }

            bool nadoFix = spisok.Contains(current.ToLower());

            if (nadoFix == true && i < words.Length - 1)
            {
                result.Append(current + "~");
            }
            else
            {
                result.Append(current + " ");
            }
        }

        return result.ToString();
    }
}